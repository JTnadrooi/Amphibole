class Enemy {
    constructor(){
        this.frameX = 0;
        this.frameY = 0;
        this.fps =20;
        this.frameInterval = 1000/this.fps;
        this.Frametimer = 0;
    }
    update(deltaTime){
    //movement
    this.x -= this.speedX + this.game.speed;
    this.y += this.speedY;
    if (this.frameTimer > this.frameInterval){
        
    }

    }
    draw(){

    }

}

class groundEnemy extends Enemy {
    constructor(game){
        super();
        this.game =game;
        this.width = 50;
        this.height - 50
        this.x = this.game.width;
        this.y = this.game.height -this.height - this.game.groundMargin;
        this.image = document.getElementById("enemy1") 
        this.speedX = 3;
        this.speedY = 3;
        this.maxFrame = 5; 
    }


}