<p align="center">
<img src="media/amphiboleFull.png" alt="headerImg">
</p>

<h1 align="center">Amphibole (Preview)</h1>

<h4 align="center">The main repo for the "Amphibole" schoolproject.</h4>

<p align="center">

# Made by the "Tinkerers" Team

The team consists of me ([JTnadrooi](https://github.com/JTnadrooi)), [Timo-Alt](https://github.com/Timo-alt), [userdaniel083](https://github.com/userdaniel083) and [MikeValpoort](https://github.com/MikeValpoort)
