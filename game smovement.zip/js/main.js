function load() { // No support for for example 8x10 boards but that seems a bit unneeded.
}
//2d element conteckt krijgen
var canvas = document.querySelector("canvas");
var darwingSurface = canvas.getContext("2d");
//maakt de sprite aan
var spriteObject =
{
    x: 0,
    y: 0,
    width: 64,
    height: 64,
};
//dit creet een nieuwe als de locatie verandert
var amphiboleFull = Object.create(spriteObject);
amphiboleFull.x = 100;
amphiboleFull.y = 100;
//is de image voor de sprite
var image = new Image();
image.addEventListener("load", loadhandler, false);
image.src = "media/amphiboleFull.png"
//de veriable de de snelheid en de richtingen
var xspeed = 0;
var yspeed = 0;
var moveLeft = false;
var moveRight = false;
var moveUp = false;
var moveDown = false;
//event listener voor de arrow keys
window.addEventListener("keydown", function (e) {
    switch (e.key) {
        case "ArrowUp":
            moveUp = true;
            break;
        case "ArrowDown":
            moveDown = true;
            break;
        case "ArrowLeft":
            moveLeft = true;
            break;
        case "ArrowRight":
            moveRight = true;
            break;
    }

}, false);
//hetzelfde als de vorige maar nu voor up
window.addEventListener("keyup", function (e) {
    switch (e.key) {
        case "ArrowUp":
            moveUp = false;
            break;
        case "ArrowDown":
            moveDown = false;
            break;
        case "ArrowLeft":
            moveLeft = false;
            break;
        case "ArrowRight":
            moveRight = false;
            break;
    }

}, false);
//laad de image en door de update bijft het updaten
function loadhandler() {
    update();
}
//ook weer updaten
function update() {
    //de animate loop
    window.requestAnimationFrame(update, canvas);
    amphiboleFull.x += xspeed;
    amphiboleFull.y += yspeed;
//de snelheid en de geen met de nul stoppen als je dus niks indrukt
    if (moveUp && !moveDown) {
        yspeed = -5;
    }
    if (moveDown && !moveUp) {
        yspeed = 5;
    }
    if (moveLeft && !moveRight) {
        xspeed = -5;
    }
    if (moveRight && !moveLeft) {
        xspeed = 5;
    }
    if (!moveUp && !moveDown) {
        yspeed = 0;
    }
    if (!moveLeft && !moveRight) {
        xspeed = 0;
    }
    //zorgt ervoor dat hij in de canvas blijft
    if (amphiboleFull.x < 0) {
        xspeed = 0;
    }
    if (amphiboleFull.y < 0) {
        yspeed = 0;
    }
    if (amphiboleFull.x + amphiboleFull.width > canvas.width) {
        amphiboleFull.x = canvas.width - amphiboleFull.width;
    }
    if (amphiboleFull.y + amphiboleFull.height > canvas.height) {
        amphiboleFull.y = canvas.height - amphiboleFull.height;
    }
    render();


}
//fit render of laad de nieuwe stand van zaken elke keer 
function render() {
    darwingSurface.clearRect(0, 0, canvas.width, canvas.height);
    darwingSurface.drawImage(
        image,
        Math.floor(amphiboleFull.x), Math.floor(amphiboleFull.y),
        amphiboleFull.width, amphiboleFull.height

    );
}